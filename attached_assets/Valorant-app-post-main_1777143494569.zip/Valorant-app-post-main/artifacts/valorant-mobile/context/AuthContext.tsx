import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useContext, useEffect, useState } from "react";

interface User {
  username: string;
  email: string;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<boolean>;
  register: (username: string, email: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoading: true,
  login: async () => false,
  register: async () => false,
  logout: async () => {},
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadUser();
  }, []);

  async function loadUser() {
    try {
      const stored = await AsyncStorage.getItem("valorant_user");
      if (stored) {
        setUser(JSON.parse(stored));
      }
    } catch {}
    setIsLoading(false);
  }

  async function login(username: string, password: string): Promise<boolean> {
    if (!username.trim() || !password.trim()) return false;
    try {
      const stored = await AsyncStorage.getItem(`valorant_account_${username.toLowerCase()}`);
      if (!stored) return false;
      const account = JSON.parse(stored);
      if (account.password !== password) return false;
      const userData = { username: account.username, email: account.email };
      setUser(userData);
      await AsyncStorage.setItem("valorant_user", JSON.stringify(userData));
      return true;
    } catch {
      return false;
    }
  }

  async function register(username: string, email: string, password: string): Promise<boolean> {
    if (!username.trim() || !email.trim() || !password.trim()) return false;
    try {
      const existing = await AsyncStorage.getItem(`valorant_account_${username.toLowerCase()}`);
      if (existing) return false;
      const account = { username, email, password };
      await AsyncStorage.setItem(`valorant_account_${username.toLowerCase()}`, JSON.stringify(account));
      const userData = { username, email };
      setUser(userData);
      await AsyncStorage.setItem("valorant_user", JSON.stringify(userData));
      return true;
    } catch {
      return false;
    }
  }

  async function logout() {
    await AsyncStorage.removeItem("valorant_user");
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, isLoading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
