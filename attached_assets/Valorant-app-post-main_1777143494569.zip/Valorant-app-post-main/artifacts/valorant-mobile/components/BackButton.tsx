import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React from "react";
import { Pressable, StyleSheet } from "react-native";
import { useColors } from "@/hooks/useColors";

export function BackButton() {
  const router = useRouter();
  const colors = useColors();

  return (
    <Pressable
      style={[styles.btn, { backgroundColor: colors.card }]}
      onPress={() => router.back()}
    >
      <Feather name="arrow-left" size={20} color={colors.foreground} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  btn: {
    width: 38,
    height: 38,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    marginLeft: 4,
  },
});
