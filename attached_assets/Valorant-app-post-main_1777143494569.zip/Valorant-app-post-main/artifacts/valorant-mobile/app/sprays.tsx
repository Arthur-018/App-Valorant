import { Feather } from "@expo/vector-icons";
import { useQuery } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import React, { useState } from "react";
import {
  FlatList,
  Image,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { ErrorView } from "@/components/ErrorView";
import { LoadingScreen } from "@/components/LoadingScreen";
import { useColors } from "@/hooks/useColors";

interface Spray {
  uuid: string;
  displayName: string;
  displayIcon?: string;
  animationPng?: string;
  fullTransparentIcon?: string;
}

async function fetchSprays(): Promise<Spray[]> {
  const res = await fetch("https://valorant-api.com/v1/sprays?language=pt-BR");
  const data = await res.json();
  return data.data;
}

export default function SpraysScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [search, setSearch] = useState("");

  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ["sprays"],
    queryFn: fetchSprays,
  });

  const topPad = Platform.OS === "web" ? Math.max(insets.top, 67) : insets.top;

  const filtered = data?.filter((s) =>
    s.displayName.toLowerCase().includes(search.toLowerCase())
  );

  if (isLoading) return <LoadingScreen message="Carregando sprays..." />;
  if (isError) return <ErrorView message="Não foi possível carregar os sprays" onRetry={refetch} />;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View style={[styles.headerBar, { paddingTop: topPad + 8, backgroundColor: colors.background }]}>
        <Pressable style={[styles.backBtn, { backgroundColor: colors.card }]} onPress={() => router.back()}>
          <Feather name="arrow-left" size={20} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Sprays</Text>
        <View style={{ width: 38 }} />
      </View>

      <View style={{ marginHorizontal: 16, marginBottom: 12 }}>
        <View style={[styles.searchBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="search" size={16} color={colors.textSecondary} />
          <TextInput
            style={[styles.searchInput, { color: colors.foreground }]}
            placeholder="Buscar spray..."
            placeholderTextColor={colors.textTertiary}
            value={search}
            onChangeText={setSearch}
          />
        </View>
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.uuid}
        numColumns={3}
        columnWrapperStyle={{ gap: 10 }}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: (Platform.OS === "web" ? 34 : insets.bottom) + 20 }}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => {
          const img = item.fullTransparentIcon || item.displayIcon;
          return (
            <View style={[styles.sprayCard, { backgroundColor: colors.card }]}>
              <View style={[styles.imgBox, { backgroundColor: colors.surfaceElevated }]}>
                {img ? (
                  <Image source={{ uri: img }} style={styles.sprayImg} resizeMode="contain" />
                ) : (
                  <Feather name="zap" size={24} color={colors.textTertiary} />
                )}
              </View>
              <Text style={[styles.sprayName, { color: colors.foreground }]} numberOfLines={2}>
                {item.displayName}
              </Text>
            </View>
          );
        }}
        ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  headerBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 12,
  },
  backBtn: { width: 38, height: 38, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  headerTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  searchBox: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 12,
    height: 44,
    gap: 8,
  },
  searchInput: { flex: 1, fontSize: 14, fontFamily: "Inter_400Regular" },
  sprayCard: { flex: 1, borderRadius: 12, padding: 10, alignItems: "center", gap: 8 },
  imgBox: { width: 70, height: 70, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  sprayImg: { width: 60, height: 60 },
  sprayName: { fontSize: 11, fontFamily: "Inter_500Medium", textAlign: "center" },
});
