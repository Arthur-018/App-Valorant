import { Feather } from "@expo/vector-icons";
import { useQuery } from "@tanstack/react-query";
import { useLocalSearchParams, useRouter } from "expo-router";
import React from "react";
import {
  Dimensions,
  Image,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { ErrorView } from "@/components/ErrorView";
import { LoadingScreen } from "@/components/LoadingScreen";
import { useColors } from "@/hooks/useColors";

const { width } = Dimensions.get("window");

interface Ability {
  slot: string;
  displayName: string;
  description: string;
  displayIcon?: string;
}

interface Agent {
  uuid: string;
  displayName: string;
  description: string;
  role?: { displayName: string; displayIcon: string; description: string };
  displayIcon: string;
  fullPortrait?: string;
  background?: string;
  backgroundGradientColors?: string[];
  abilities: Ability[];
}

async function fetchAgent(uuid: string): Promise<Agent> {
  const res = await fetch(`https://valorant-api.com/v1/agents/${uuid}?language=pt-BR`);
  const data = await res.json();
  return data.data;
}

export default function AgentDetailScreen() {
  const { uuid } = useLocalSearchParams<{ uuid: string }>();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const { data: agent, isLoading, isError, refetch } = useQuery({
    queryKey: ["agent", uuid],
    queryFn: () => fetchAgent(uuid!),
    enabled: !!uuid,
  });

  const topPad = Platform.OS === "web" ? Math.max(insets.top, 67) : insets.top;

  if (isLoading) return <LoadingScreen message="Carregando agente..." />;
  if (isError || !agent) return <ErrorView onRetry={refetch} />;

  const gradColors = agent.backgroundGradientColors;
  const bgHex = gradColors && gradColors.length > 0 ? `#${gradColors[0]}` : colors.card;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={[styles.hero, { backgroundColor: bgHex, paddingTop: topPad + 8 }]}>
          <View style={styles.heroHeader}>
            <Pressable style={[styles.backBtn, { backgroundColor: "rgba(0,0,0,0.3)" }]} onPress={() => router.back()}>
              <Feather name="arrow-left" size={20} color="#fff" />
            </Pressable>
          </View>
          <View style={[styles.heroBg, { opacity: 0.1 }]}>
            {agent.background ? (
              <Image source={{ uri: agent.background }} style={StyleSheet.absoluteFill} resizeMode="cover" />
            ) : null}
          </View>
          {agent.fullPortrait || agent.displayIcon ? (
            <Image
              source={{ uri: agent.fullPortrait || agent.displayIcon }}
              style={styles.heroPortrait}
              resizeMode="contain"
            />
          ) : null}
          <View style={styles.heroFooter}>
            {agent.role ? (
              <View style={[styles.rolePill, { backgroundColor: "rgba(0,0,0,0.4)" }]}>
                <Text style={styles.rolePillText}>{agent.role.displayName}</Text>
              </View>
            ) : null}
            <Text style={styles.heroName}>{agent.displayName}</Text>
          </View>
        </View>

        <View style={[styles.body, { paddingBottom: (Platform.OS === "web" ? 34 : insets.bottom) + 24 }]}>
          <View style={[styles.section, { backgroundColor: colors.card }]}>
            <Text style={[styles.sectionLabel, { color: colors.textSecondary }]}>Sobre</Text>
            <Text style={[styles.description, { color: colors.foreground }]}>{agent.description}</Text>
          </View>

          {agent.role && agent.role.description ? (
            <View style={[styles.section, { backgroundColor: colors.card }]}>
              <Text style={[styles.sectionLabel, { color: colors.textSecondary }]}>Função</Text>
              <Text style={[styles.description, { color: colors.foreground }]}>{agent.role.description}</Text>
            </View>
          ) : null}

          {agent.abilities && agent.abilities.length > 0 ? (
            <View style={{ paddingHorizontal: 16 }}>
              <Text style={[styles.abilitiesTitle, { color: colors.foreground }]}>Habilidades</Text>
              {agent.abilities.map((ab) => (
                <View key={ab.slot} style={[styles.abilityRow, { backgroundColor: colors.card }]}>
                  {ab.displayIcon ? (
                    <Image source={{ uri: ab.displayIcon }} style={styles.abilityIcon} />
                  ) : (
                    <View style={[styles.abilityIconPlaceholder, { backgroundColor: colors.surface }]}>
                      <Feather name="zap" size={16} color={colors.primary} />
                    </View>
                  )}
                  <View style={styles.abilityInfo}>
                    <Text style={[styles.abilityName, { color: colors.foreground }]}>{ab.displayName}</Text>
                    <Text style={[styles.abilityDesc, { color: colors.textSecondary }]} numberOfLines={3}>
                      {ab.description}
                    </Text>
                  </View>
                </View>
              ))}
            </View>
          ) : null}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  hero: { height: 360, overflow: "hidden", position: "relative" },
  heroHeader: { paddingHorizontal: 16, paddingBottom: 8, zIndex: 3 },
  heroBg: { position: "absolute", top: 0, left: 0, right: 0, bottom: 0 },
  heroPortrait: {
    position: "absolute",
    bottom: 0,
    right: -20,
    width: width * 0.7,
    height: 320,
    zIndex: 2,
  },
  heroFooter: { position: "absolute", bottom: 24, left: 20, zIndex: 3 },
  backBtn: { width: 38, height: 38, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  rolePill: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8, alignSelf: "flex-start", marginBottom: 6 },
  rolePillText: { color: "#fff", fontSize: 11, fontFamily: "Inter_500Medium" },
  heroName: { color: "#fff", fontSize: 30, fontFamily: "Inter_700Bold" },
  body: { paddingTop: 16, gap: 12 },
  section: { marginHorizontal: 16, borderRadius: 14, padding: 16 },
  sectionLabel: { fontSize: 12, fontFamily: "Inter_500Medium", letterSpacing: 0.5, marginBottom: 8 },
  description: { fontSize: 14, fontFamily: "Inter_400Regular", lineHeight: 22 },
  abilitiesTitle: { fontSize: 16, fontFamily: "Inter_700Bold", marginBottom: 12 },
  abilityRow: {
    flexDirection: "row",
    borderRadius: 12,
    padding: 14,
    marginBottom: 10,
    gap: 12,
    alignItems: "flex-start",
  },
  abilityIcon: { width: 40, height: 40, borderRadius: 8 },
  abilityIconPlaceholder: { width: 40, height: 40, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  abilityInfo: { flex: 1 },
  abilityName: { fontSize: 14, fontFamily: "Inter_600SemiBold", marginBottom: 4 },
  abilityDesc: { fontSize: 13, fontFamily: "Inter_400Regular", lineHeight: 19 },
});
