import { Feather } from "@expo/vector-icons";
import { useQuery } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import React, { useState } from "react";
import {
  FlatList,
  Image,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { ErrorView } from "@/components/ErrorView";
import { LoadingScreen } from "@/components/LoadingScreen";
import { useColors } from "@/hooks/useColors";

interface Agent {
  uuid: string;
  displayName: string;
  description: string;
  role?: { displayName: string; displayIcon: string };
  displayIcon: string;
  background?: string;
  backgroundGradientColors?: string[];
}

async function fetchAgents(): Promise<Agent[]> {
  const res = await fetch("https://valorant-api.com/v1/agents?isPlayableCharacter=true&language=pt-BR");
  const data = await res.json();
  return data.data;
}

export default function AgentsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [search, setSearch] = useState("");

  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ["agents"],
    queryFn: fetchAgents,
  });

  const topPad = Platform.OS === "web" ? Math.max(insets.top, 67) : insets.top;

  const filtered = data?.filter((a) =>
    a.displayName.toLowerCase().includes(search.toLowerCase())
  );

  if (isLoading) return <LoadingScreen message="Carregando agentes..." />;
  if (isError) return <ErrorView message="Não foi possível carregar os agentes" onRetry={refetch} />;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View style={[styles.headerBar, { paddingTop: topPad + 8, backgroundColor: colors.background }]}>
        <Pressable style={[styles.backBtn, { backgroundColor: colors.card }]} onPress={() => router.back()}>
          <Feather name="arrow-left" size={20} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Agentes</Text>
        <View style={{ width: 38 }} />
      </View>

      <View style={[styles.searchRow, { marginHorizontal: 16, marginBottom: 12 }]}>
        <View style={[styles.searchBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="search" size={16} color={colors.textSecondary} />
          <TextInput
            style={[styles.searchInput, { color: colors.foreground }]}
            placeholder="Buscar agente..."
            placeholderTextColor={colors.textTertiary}
            value={search}
            onChangeText={setSearch}
          />
          {search ? (
            <Pressable onPress={() => setSearch("")}>
              <Feather name="x" size={16} color={colors.textSecondary} />
            </Pressable>
          ) : null}
        </View>
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.uuid}
        numColumns={2}
        columnWrapperStyle={styles.row}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: (Platform.OS === "web" ? 34 : insets.bottom) + 20 }}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => {
          const gradColors = item.backgroundGradientColors;
          const bgColor = gradColors && gradColors.length > 0 ? `#${gradColors[0]}` : colors.card;
          return (
            <Pressable
              style={[styles.agentCard, { backgroundColor: bgColor }]}
              onPress={() => router.push({ pathname: "/agent-detail", params: { uuid: item.uuid } })}
            >
              <View style={[styles.agentOverlay, { backgroundColor: "rgba(0,0,0,0.35)" }]} />
              {item.displayIcon ? (
                <Image source={{ uri: item.displayIcon }} style={styles.agentImage} resizeMode="contain" />
              ) : null}
              <View style={styles.agentInfo}>
                {item.role ? (
                  <View style={[styles.roleBadge, { backgroundColor: "rgba(255,255,255,0.15)" }]}>
                    <Text style={styles.roleText}>{item.role.displayName}</Text>
                  </View>
                ) : null}
                <Text style={styles.agentName} numberOfLines={1}>{item.displayName}</Text>
              </View>
            </Pressable>
          );
        }}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Feather name="search" size={32} color={colors.textSecondary} />
            <Text style={[styles.emptyText, { color: colors.textSecondary }]}>Nenhum agente encontrado</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  headerBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 12,
  },
  backBtn: { width: 38, height: 38, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  headerTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  searchRow: {},
  searchBox: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 12,
    height: 44,
    gap: 8,
  },
  searchInput: { flex: 1, fontSize: 14, fontFamily: "Inter_400Regular" },
  row: { gap: 10, marginBottom: 10 },
  agentCard: {
    flex: 1,
    height: 200,
    borderRadius: 14,
    overflow: "hidden",
    position: "relative",
  },
  agentOverlay: { position: "absolute", top: 0, left: 0, right: 0, bottom: 0 },
  agentImage: { position: "absolute", bottom: 0, right: -10, width: 130, height: 160 },
  agentInfo: { position: "absolute", bottom: 12, left: 10, right: 10 },
  roleBadge: {
    alignSelf: "flex-start",
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
    marginBottom: 4,
  },
  roleText: { color: "#fff", fontSize: 10, fontFamily: "Inter_500Medium" },
  agentName: { color: "#fff", fontSize: 15, fontFamily: "Inter_700Bold" },
  empty: { alignItems: "center", paddingTop: 60, gap: 12 },
  emptyText: { fontSize: 15, fontFamily: "Inter_400Regular" },
});
