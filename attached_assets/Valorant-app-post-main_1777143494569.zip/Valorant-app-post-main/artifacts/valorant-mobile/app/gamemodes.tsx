import { Feather } from "@expo/vector-icons";
import { useQuery } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import React from "react";
import {
  FlatList,
  Image,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { ErrorView } from "@/components/ErrorView";
import { LoadingScreen } from "@/components/LoadingScreen";
import { useColors } from "@/hooks/useColors";

interface GameMode {
  uuid: string;
  displayName: string;
  description?: string;
  duration?: string;
  economyType?: string;
  allowsMatchTimeouts?: boolean;
  isTeamVoiceAllowed?: boolean;
  isMinimapHidden?: boolean;
  orbCount?: number;
  teamRoles?: string[];
  displayIcon?: string;
}

async function fetchGameModes(): Promise<GameMode[]> {
  const res = await fetch("https://valorant-api.com/v1/gamemodes?language=pt-BR");
  const data = await res.json();
  return data.data.filter((m: GameMode) => m.displayName && m.displayName.length > 0);
}

export default function GameModesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ["gamemodes"],
    queryFn: fetchGameModes,
  });

  const topPad = Platform.OS === "web" ? Math.max(insets.top, 67) : insets.top;

  if (isLoading) return <LoadingScreen message="Carregando modos..." />;
  if (isError) return <ErrorView message="Não foi possível carregar os modos de jogo" onRetry={refetch} />;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View style={[styles.headerBar, { paddingTop: topPad + 8, backgroundColor: colors.background }]}>
        <Pressable style={[styles.backBtn, { backgroundColor: colors.card }]} onPress={() => router.back()}>
          <Feather name="arrow-left" size={20} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Modos de Jogo</Text>
        <View style={{ width: 38 }} />
      </View>

      <FlatList
        data={data}
        keyExtractor={(item) => item.uuid}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: (Platform.OS === "web" ? 34 : insets.bottom) + 20, gap: 12 }}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <View style={[styles.modeCard, { backgroundColor: colors.card }]}>
            <View style={[styles.modeIconBox, { backgroundColor: colors.surfaceElevated }]}>
              {item.displayIcon ? (
                <Image source={{ uri: item.displayIcon }} style={styles.modeIcon} resizeMode="contain" />
              ) : (
                <Feather name="play-circle" size={28} color={colors.primary} />
              )}
            </View>
            <View style={styles.modeInfo}>
              <Text style={[styles.modeName, { color: colors.foreground }]}>{item.displayName}</Text>
              {item.description ? (
                <Text style={[styles.modeDesc, { color: colors.textSecondary }]} numberOfLines={2}>
                  {item.description}
                </Text>
              ) : null}
              <View style={styles.modeMeta}>
                {item.duration ? (
                  <View style={[styles.metaBadge, { backgroundColor: colors.surfaceElevated }]}>
                    <Feather name="clock" size={11} color={colors.textSecondary} />
                    <Text style={[styles.metaBadgeText, { color: colors.textSecondary }]}>{item.duration}</Text>
                  </View>
                ) : null}
                {item.orbCount !== undefined && item.orbCount > 0 ? (
                  <View style={[styles.metaBadge, { backgroundColor: colors.surfaceElevated }]}>
                    <Text style={[styles.metaBadgeText, { color: colors.textSecondary }]}>{item.orbCount} Orbes</Text>
                  </View>
                ) : null}
              </View>
            </View>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  headerBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 12,
  },
  backBtn: { width: 38, height: 38, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  headerTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  modeCard: { flexDirection: "row", borderRadius: 14, padding: 14, gap: 14, alignItems: "flex-start" },
  modeIconBox: { width: 56, height: 56, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  modeIcon: { width: 40, height: 40 },
  modeInfo: { flex: 1, gap: 4 },
  modeName: { fontSize: 17, fontFamily: "Inter_700Bold" },
  modeDesc: { fontSize: 13, fontFamily: "Inter_400Regular", lineHeight: 18 },
  modeMeta: { flexDirection: "row", gap: 6, marginTop: 4 },
  metaBadge: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  metaBadgeText: { fontSize: 11, fontFamily: "Inter_400Regular" },
});
