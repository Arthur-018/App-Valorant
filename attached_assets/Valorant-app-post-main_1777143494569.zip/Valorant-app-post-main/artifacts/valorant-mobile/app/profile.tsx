import { Feather } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Haptics from "expo-haptics";
import { Image } from "expo-image";
import { useRouter } from "expo-router";
import * as WebBrowser from "expo-web-browser";
import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Animated,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";

const HISTORY_KEY = "valorant_riot_id_history";
const MAX_HISTORY = 8;

const REGION_MAP: Record<string, { label: string; color: string }> = {
  BR1: { label: "Brasil", color: "#56B847" },
  NA1: { label: "América do Norte", color: "#4A90E2" },
  NA: { label: "América do Norte", color: "#4A90E2" },
  EUW: { label: "Europa Oeste", color: "#7B5BD2" },
  EUW1: { label: "Europa Oeste", color: "#7B5BD2" },
  EUNE: { label: "Europa N/L", color: "#9B59B6" },
  KR: { label: "Coreia", color: "#E74C3C" },
  JP1: { label: "Japão", color: "#E74C3C" },
  JP: { label: "Japão", color: "#E74C3C" },
  LA1: { label: "América Latina N", color: "#F5A623" },
  LA2: { label: "América Latina S", color: "#F5A623" },
  OC1: { label: "Oceania", color: "#1ABC9C" },
  AP: { label: "Ásia-Pacífico", color: "#00C4B4" },
  ME1: { label: "Oriente Médio", color: "#F39C12" },
  TR1: { label: "Turquia", color: "#E74C3C" },
  RU: { label: "Rússia", color: "#95A5A6" },
};

function getRegion(tag: string) {
  return REGION_MAP[tag.toUpperCase()] ?? { label: tag.toUpperCase(), color: "#8B9BA8" };
}
function getInitials(name: string) {
  return name.split(/\s+/).map((w) => w[0]?.toUpperCase() ?? "").slice(0, 2).join("");
}
function isValidRiotId(v: string) { return /^.{1,}#.{3,5}$/.test(v.trim()); }
function parseRiotId(v: string) {
  const idx = v.lastIndexOf("#");
  if (idx === -1) return null;
  const name = v.slice(0, idx).trim(), tag = v.slice(idx + 1).trim();
  return name && tag ? { name, tag } : null;
}
function timeAgo(ms: number) {
  if (!ms) return "—";
  const diff = Date.now() - ms;
  const m = Math.floor(diff / 60000);
  if (m < 60) return `${m}m atrás`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h atrás`;
  return `${Math.floor(h / 24)}d atrás`;
}
function getApiBase() {
  const d = process.env["EXPO_PUBLIC_DOMAIN"];
  return d ? `https://${d}/api` : "/api";
}

type ProfileData = {
  account: { puuid: string; gameName: string; tagLine: string; shard: string };
  season: { act: { id: string; name: string } | null; episode: { id: string; name: string } | null; gameVersion: string | null };
  dataAvailability: { matches: boolean; matchDetails: boolean; rank: boolean };
  overview: {
    totalGames: number; wins: number; losses: number; winRate: number;
    kdRatio: string; kdaRatio: string; avgACS: number;
    avgKills: string; avgDeaths: string; avgAssists: string;
    lastKnownRank: string; lastKnownTier: number;
    totalKills: number; totalDeaths: number; totalAssists: number;
  } | null;
  topAgents: Array<{
    id: string; name: string; iconUrl: string;
    games: number; wins: number; winRate: number;
    kills: number; deaths: number; kd: string; avgACS: number;
  }>;
  recentMatches: Array<{
    matchId: string; queue: string; queueLabel: string; startedAt: number;
    result: "win" | "loss"; agent: { id: string; name: string; iconUrl: string };
    map: string; roundsWon: number; roundsLost: number;
    kills: number; deaths: number; assists: number; acs: number; kd: string;
    isRanked: boolean; competitiveTier: number; rankName: string; roundsPlayed: number;
  }>;
};

async function fetchProfile(name: string, tag: string): Promise<ProfileData> {
  const res = await fetch(`${getApiBase()}/riot/profile?name=${encodeURIComponent(name)}&tag=${encodeURIComponent(tag)}`);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error ?? "Erro ao buscar perfil.");
  return data as ProfileData;
}

async function loadHistory() {
  try { const r = await AsyncStorage.getItem(HISTORY_KEY); return r ? JSON.parse(r) as string[] : []; } catch { return []; }
}
async function saveHistory(id: string, hist: string[]) {
  const next = [id, ...hist.filter((h) => h.toLowerCase() !== id.toLowerCase())].slice(0, MAX_HISTORY);
  await AsyncStorage.setItem(HISTORY_KEY, JSON.stringify(next)); return next;
}
async function removeHistory(id: string, hist: string[]) {
  const next = hist.filter((h) => h.toLowerCase() !== id.toLowerCase());
  await AsyncStorage.setItem(HISTORY_KEY, JSON.stringify(next)); return next;
}

function SectionTitle({ label, colors }: { label: string; colors: ReturnType<typeof useColors> }) {
  return (
    <View style={secStyles.row}>
      <View style={[secStyles.bar, { backgroundColor: colors.primary }]} />
      <Text style={[secStyles.title, { color: colors.foreground }]}>{label}</Text>
    </View>
  );
}
const secStyles = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 12 },
  bar: { width: 3, height: 16, borderRadius: 2 },
  title: { fontSize: 13, fontFamily: "Inter_700Bold", letterSpacing: 0.8, textTransform: "uppercase" },
});

function EmptyState({ icon, title, sub, colors }: { icon: string; title: string; sub: string; colors: ReturnType<typeof useColors> }) {
  return (
    <View style={[emStyles.box, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <Feather name={icon as any} size={22} color={colors.textTertiary} />
      <Text style={[emStyles.title, { color: colors.textSecondary }]}>{title}</Text>
      <Text style={[emStyles.sub, { color: colors.textTertiary }]}>{sub}</Text>
    </View>
  );
}
const emStyles = StyleSheet.create({
  box: { borderRadius: 14, borderWidth: 1, padding: 24, alignItems: "center", gap: 8 },
  title: { fontSize: 14, fontFamily: "Inter_600SemiBold", textAlign: "center" },
  sub: { fontSize: 12, fontFamily: "Inter_400Regular", textAlign: "center", lineHeight: 18 },
});

function StatBox({ label, value, sub, accent, colors }: { label: string; value: string; sub?: string; accent?: string; colors: ReturnType<typeof useColors> }) {
  return (
    <View style={[sbStyles.box, { backgroundColor: colors.card }]}>
      <Text style={[sbStyles.value, { color: accent ?? colors.foreground }]}>{value}</Text>
      <Text style={[sbStyles.label, { color: colors.textSecondary }]}>{label}</Text>
      {sub ? <Text style={[sbStyles.sub, { color: colors.textTertiary }]}>{sub}</Text> : null}
    </View>
  );
}
const sbStyles = StyleSheet.create({
  box: { flex: 1, borderRadius: 12, padding: 14, alignItems: "center", gap: 3, minWidth: 70 },
  value: { fontSize: 22, fontFamily: "Inter_700Bold" },
  label: { fontSize: 11, fontFamily: "Inter_500Medium", letterSpacing: 0.3 },
  sub: { fontSize: 10, fontFamily: "Inter_400Regular" },
});

function WinRateRing({ rate, wins, losses, colors }: { rate: number; wins: number; losses: number; colors: ReturnType<typeof useColors> }) {
  const color = rate >= 50 ? "#56B847" : colors.primary;
  return (
    <View style={[wrStyles.container, { backgroundColor: colors.card }]}>
      <View style={[wrStyles.ring, { borderColor: color + "33" }]}>
        <View style={[wrStyles.innerRing, { borderColor: color }]} />
        <Text style={[wrStyles.pct, { color }]}>{rate}%</Text>
        <Text style={[wrStyles.label, { color: colors.textTertiary }]}>WR</Text>
      </View>
      <View style={wrStyles.detail}>
        <Text style={[wrStyles.detTitle, { color: colors.foreground }]}>Taxa de Vitória</Text>
        <View style={wrStyles.wlRow}>
          <View style={[wrStyles.wlBadge, { backgroundColor: "#56B84722" }]}><Text style={{ color: "#56B847", fontSize: 12, fontFamily: "Inter_700Bold" }}>V {wins}</Text></View>
          <View style={[wrStyles.wlBadge, { backgroundColor: colors.primary + "22" }]}><Text style={{ color: colors.primary, fontSize: 12, fontFamily: "Inter_700Bold" }}>D {losses}</Text></View>
        </View>
      </View>
    </View>
  );
}
const wrStyles = StyleSheet.create({
  container: { flexDirection: "row", alignItems: "center", borderRadius: 14, padding: 16, gap: 16 },
  ring: { width: 72, height: 72, borderRadius: 36, borderWidth: 6, alignItems: "center", justifyContent: "center", position: "relative" },
  innerRing: { position: "absolute", width: 58, height: 58, borderRadius: 29, borderWidth: 3, borderStyle: "solid" },
  pct: { fontSize: 18, fontFamily: "Inter_700Bold" },
  label: { fontSize: 10, fontFamily: "Inter_500Medium" },
  detail: { flex: 1, gap: 8 },
  detTitle: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  wlRow: { flexDirection: "row", gap: 8 },
  wlBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
});

function AgentCard({ agent, colors }: { agent: ProfileData["topAgents"][0]; colors: ReturnType<typeof useColors> }) {
  return (
    <View style={[acStyles.card, { backgroundColor: colors.card }]}>
      {agent.iconUrl ? (
        <Image source={{ uri: agent.iconUrl }} style={acStyles.icon} contentFit="contain" />
      ) : (
        <View style={[acStyles.iconPlaceholder, { backgroundColor: colors.surfaceElevated }]}>
          <Feather name="user" size={18} color={colors.textSecondary} />
        </View>
      )}
      <Text style={[acStyles.name, { color: colors.foreground }]} numberOfLines={1}>{agent.name}</Text>
      <Text style={[acStyles.games, { color: colors.textSecondary }]}>{agent.games} {agent.games === 1 ? "partida" : "partidas"}</Text>
      <View style={acStyles.statsRow}>
        <View style={acStyles.statItem}>
          <Text style={[acStyles.statVal, { color: colors.foreground }]}>{agent.kd}</Text>
          <Text style={[acStyles.statLabel, { color: colors.textTertiary }]}>K/D</Text>
        </View>
        <View style={[acStyles.sep, { backgroundColor: colors.border }]} />
        <View style={acStyles.statItem}>
          <Text style={[acStyles.statVal, { color: agent.winRate >= 50 ? "#56B847" : colors.primary }]}>{agent.winRate}%</Text>
          <Text style={[acStyles.statLabel, { color: colors.textTertiary }]}>WR</Text>
        </View>
        <View style={[acStyles.sep, { backgroundColor: colors.border }]} />
        <View style={acStyles.statItem}>
          <Text style={[acStyles.statVal, { color: colors.foreground }]}>{agent.avgACS}</Text>
          <Text style={[acStyles.statLabel, { color: colors.textTertiary }]}>ACS</Text>
        </View>
      </View>
    </View>
  );
}
const acStyles = StyleSheet.create({
  card: { width: 130, borderRadius: 14, padding: 14, alignItems: "center", gap: 6 },
  icon: { width: 52, height: 52 },
  iconPlaceholder: { width: 52, height: 52, borderRadius: 26, alignItems: "center", justifyContent: "center" },
  name: { fontSize: 13, fontFamily: "Inter_700Bold", textAlign: "center" },
  games: { fontSize: 11, fontFamily: "Inter_400Regular" },
  statsRow: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: 4 },
  statItem: { alignItems: "center", gap: 1 },
  statVal: { fontSize: 13, fontFamily: "Inter_700Bold" },
  statLabel: { fontSize: 10, fontFamily: "Inter_400Regular" },
  sep: { width: 1, height: 20 },
});

function MatchCard({ match, colors }: { match: ProfileData["recentMatches"][0]; colors: ReturnType<typeof useColors> }) {
  const isWin = match.result === "win";
  const resultColor = isWin ? "#56B847" : colors.primary;
  return (
    <View style={[mcStyles.card, { backgroundColor: colors.card, borderLeftColor: resultColor, borderLeftWidth: 3 }]}>
      <View style={mcStyles.left}>
        {match.agent.iconUrl ? (
          <Image source={{ uri: match.agent.iconUrl }} style={mcStyles.agentIcon} contentFit="contain" />
        ) : (
          <View style={[mcStyles.agentIconPlaceholder, { backgroundColor: colors.surfaceElevated }]}>
            <Feather name="user" size={16} color={colors.textSecondary} />
          </View>
        )}
        <View style={mcStyles.agentInfo}>
          <Text style={[mcStyles.agentName, { color: colors.foreground }]} numberOfLines={1}>{match.agent.name}</Text>
          <Text style={[mcStyles.mapName, { color: colors.textSecondary }]}>{match.map}</Text>
          <Text style={[mcStyles.queue, { color: colors.textTertiary }]}>{match.queueLabel}</Text>
        </View>
      </View>

      <View style={mcStyles.center}>
        <View style={[mcStyles.resultBadge, { backgroundColor: resultColor + "22" }]}>
          <Text style={[mcStyles.resultText, { color: resultColor }]}>{isWin ? "VITÓRIA" : "DERROTA"}</Text>
        </View>
        <Text style={[mcStyles.score, { color: colors.foreground }]}>
          {match.roundsWon} — {match.roundsLost}
        </Text>
      </View>

      <View style={mcStyles.right}>
        <Text style={[mcStyles.kda, { color: colors.foreground }]}>{match.kills}/{match.deaths}/{match.assists}</Text>
        <Text style={[mcStyles.kdLabel, { color: colors.textSecondary }]}>K / D / A</Text>
        <View style={[mcStyles.acsBadge, { backgroundColor: colors.surfaceElevated }]}>
          <Text style={[mcStyles.acsText, { color: colors.foreground }]}>{match.acs} ACS</Text>
        </View>
        <Text style={[mcStyles.timeAgo, { color: colors.textTertiary }]}>{timeAgo(match.startedAt)}</Text>
      </View>
    </View>
  );
}
const mcStyles = StyleSheet.create({
  card: { borderRadius: 14, padding: 14, flexDirection: "row", alignItems: "center", gap: 10 },
  left: { flexDirection: "row", alignItems: "center", gap: 10, flex: 1.2 },
  agentIcon: { width: 42, height: 42 },
  agentIconPlaceholder: { width: 42, height: 42, borderRadius: 21, alignItems: "center", justifyContent: "center" },
  agentInfo: { flex: 1, gap: 2 },
  agentName: { fontSize: 13, fontFamily: "Inter_700Bold" },
  mapName: { fontSize: 11, fontFamily: "Inter_400Regular" },
  queue: { fontSize: 10, fontFamily: "Inter_400Regular" },
  center: { alignItems: "center", gap: 4 },
  resultBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  resultText: { fontSize: 10, fontFamily: "Inter_700Bold", letterSpacing: 0.5 },
  score: { fontSize: 13, fontFamily: "Inter_700Bold" },
  right: { alignItems: "flex-end", gap: 3, flex: 1 },
  kda: { fontSize: 15, fontFamily: "Inter_700Bold" },
  kdLabel: { fontSize: 10, fontFamily: "Inter_400Regular" },
  acsBadge: { paddingHorizontal: 7, paddingVertical: 2, borderRadius: 6 },
  acsText: { fontSize: 11, fontFamily: "Inter_600SemiBold" },
  timeAgo: { fontSize: 10, fontFamily: "Inter_400Regular" },
});

function TrackerView({
  data, onClear, onOpenTracker, onOpenBlitz, colors,
}: {
  data: ProfileData; onClear: () => void;
  onOpenTracker: () => void; onOpenBlitz: () => void;
  colors: ReturnType<typeof useColors>;
}) {
  const region = getRegion(data.account.tagLine);
  const initials = getInitials(data.account.gameName);
  const slideAnim = useRef(new Animated.Value(20)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(slideAnim, { toValue: 0, duration: 380, useNativeDriver: true }),
      Animated.timing(fadeAnim, { toValue: 1, duration: 380, useNativeDriver: true }),
    ]).start();
  }, []);

  const ov = data.overview;
  const matchesWorked = data.dataAvailability.matchDetails;
  const totalGamesLabel = ov ? `${ov.totalGames} partidas analisadas` : null;

  return (
    <Animated.View style={{ opacity: fadeAnim, transform: [{ translateY: slideAnim }], gap: 20 }}>
      {/* Player Card */}
      <View style={[tvStyles.playerCard, { backgroundColor: colors.card }]}>
        <View style={[tvStyles.playerCardBanner, { backgroundColor: colors.primary + "18" }]}>
          <View style={[tvStyles.verifiedPill, { backgroundColor: "#56B84722" }]}>
            <Feather name="check-circle" size={10} color="#56B847" />
            <Text style={[tvStyles.verifiedText, { color: "#56B847" }]}>Verificado via Riot API</Text>
          </View>
          {data.season.act && (
            <Text style={[tvStyles.seasonText, { color: colors.textTertiary }]}>
              {data.season.episode?.name} · {data.season.act.name}
            </Text>
          )}
          <Pressable onPress={onClear} style={[tvStyles.clearBtn, { backgroundColor: colors.surfaceElevated }]}>
            <Feather name="x" size={14} color={colors.textSecondary} />
          </Pressable>
        </View>

        <View style={tvStyles.playerCardBody}>
          <View style={[tvStyles.avatarCircle, { backgroundColor: colors.primary + "22", borderColor: colors.primary }]}>
            <Text style={[tvStyles.avatarInitials, { color: colors.primary }]}>{initials}</Text>
          </View>
          <Text style={[tvStyles.playerName, { color: colors.foreground }]} numberOfLines={1} adjustsFontSizeToFit>
            {data.account.gameName}
          </Text>
          <View style={tvStyles.tagRow}>
            <Text style={[tvStyles.tagText, { color: colors.textSecondary }]}>#{data.account.tagLine}</Text>
            <View style={[tvStyles.regionBadge, { backgroundColor: region.color + "22" }]}>
              <View style={[tvStyles.regionDot, { backgroundColor: region.color }]} />
              <Text style={[tvStyles.regionLabel, { color: region.color }]}>{region.label}</Text>
            </View>
          </View>
          {ov && ov.lastKnownTier > 0 && (
            <View style={[tvStyles.rankPill, { backgroundColor: colors.surfaceElevated }]}>
              <Feather name="award" size={12} color={colors.textSecondary} />
              <Text style={[tvStyles.rankText, { color: colors.textSecondary }]}>Último ranque: {ov.lastKnownRank}</Text>
            </View>
          )}
          <View style={[tvStyles.puuidRow, { backgroundColor: colors.surfaceElevated }]}>
            <Feather name="key" size={10} color={colors.textTertiary} />
            <Text style={[tvStyles.puuidText, { color: colors.textTertiary }]}>
              PUUID: ...{data.account.puuid.slice(-10).toUpperCase()}
            </Text>
          </View>
        </View>
      </View>

      {/* Overview */}
      <View>
        <SectionTitle label={ov ? `Visão Geral · ${totalGamesLabel}` : "Visão Geral"} colors={colors} />
        {ov ? (
          <View style={{ gap: 10 }}>
            <WinRateRing rate={ov.winRate} wins={ov.wins} losses={ov.losses} colors={colors} />
            <View style={{ flexDirection: "row", gap: 10 }}>
              <StatBox label="K/D" value={ov.kdRatio} sub={`${ov.avgKills} mortes avg`} colors={colors}
                accent={parseFloat(ov.kdRatio) >= 1 ? "#56B847" : colors.primary} />
              <StatBox label="KDA" value={ov.kdaRatio} colors={colors} />
              <StatBox label="ACS Médio" value={String(ov.avgACS)} colors={colors} />
            </View>
            <View style={{ flexDirection: "row", gap: 10 }}>
              <StatBox label="Abates" value={String(ov.totalKills)} sub={`${ov.avgKills}/partida`} colors={colors} />
              <StatBox label="Mortes" value={String(ov.totalDeaths)} sub={`${ov.avgDeaths}/partida`} colors={colors} />
              <StatBox label="Assistências" value={String(ov.totalAssists)} sub={`${ov.avgAssists}/partida`} colors={colors} />
            </View>
          </View>
        ) : matchesWorked ? (
          <EmptyState icon="bar-chart-2" title="Sem partidas registradas" sub="Jogue algumas partidas para que as estatísticas apareçam aqui." colors={colors} />
        ) : data.dataAvailability.matches === false ? (
          <EmptyState icon="lock" title="Dados de partidas indisponíveis" sub={"Sua chave de desenvolvedor Riot não tem acesso a val/match/v1.\nEssa permissão requer uma chave de produção aprovada pela Riot."} colors={colors} />
        ) : (
          <EmptyState icon="alert-circle" title="Estatísticas não disponíveis" sub="Não foi possível carregar os dados de partidas desta conta." colors={colors} />
        )}
      </View>

      {/* Top Agents */}
      <View>
        <SectionTitle label="Agentes Favoritos" colors={colors} />
        {data.topAgents.length > 0 ? (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10 }}>
            {data.topAgents.map((a) => <AgentCard key={a.id} agent={a} colors={colors} />)}
          </ScrollView>
        ) : matchesWorked ? (
          <EmptyState icon="user" title="Nenhum agente encontrado" sub="Nenhuma partida analisada contém dados de agente." colors={colors} />
        ) : (
          <EmptyState icon="user" title="Agentes favoritos indisponíveis" sub="Requer histórico de partidas (chave de produção Riot)." colors={colors} />
        )}
      </View>

      {/* Recent Matches */}
      <View>
        <SectionTitle label="Partidas Recentes" colors={colors} />
        {data.recentMatches.length > 0 ? (
          <View style={{ gap: 8 }}>
            {data.recentMatches.map((m) => <MatchCard key={m.matchId} match={m} colors={colors} />)}
          </View>
        ) : matchesWorked ? (
          <EmptyState icon="clock" title="Nenhuma partida recente" sub="Nenhuma partida encontrada para esta conta." colors={colors} />
        ) : (
          <EmptyState icon="clock" title="Histórico indisponível" sub={"Seu nível de acesso à API da Riot não permite consultar partidas individuais.\nIsso requer o escopo VAL_MATCH_READ (chave de produção)."} colors={colors} />
        )}
      </View>

      {/* External Links */}
      <View>
        <SectionTitle label="Perfil Externo" colors={colors} />
        <View style={[extStyles.box, { backgroundColor: colors.card }]}>
          <Text style={[extStyles.sub, { color: colors.textSecondary }]}>
            Para estatísticas avançadas, rank histórico e mais detalhes, consulte os trackers externos:
          </Text>
          <View style={extStyles.btns}>
            <Pressable style={[extStyles.btn, { backgroundColor: colors.primary }]} onPress={onOpenTracker}>
              <Feather name="bar-chart-2" size={15} color="#fff" />
              <Text style={extStyles.btnText}>Tracker.gg</Text>
              <Feather name="external-link" size={12} color="rgba(255,255,255,0.7)" />
            </Pressable>
            <Pressable style={[extStyles.btn, { backgroundColor: colors.surfaceElevated }]} onPress={onOpenBlitz}>
              <Feather name="zap" size={15} color={colors.foreground} />
              <Text style={[extStyles.btnText, { color: colors.foreground }]}>Blitz.gg</Text>
              <Feather name="external-link" size={12} color={colors.textSecondary} />
            </Pressable>
          </View>
        </View>
      </View>

      <View style={[extStyles.infoBox, { backgroundColor: colors.card }]}>
        <Feather name="lock" size={13} color={colors.textSecondary} />
        <Text style={[extStyles.infoText, { color: colors.textSecondary }]}>
          Nenhuma senha ou dado privado é solicitado. Apenas o Riot ID público é consultado via API oficial.
        </Text>
      </View>
    </Animated.View>
  );
}
const tvStyles = StyleSheet.create({
  playerCard: { borderRadius: 16, overflow: "hidden" },
  playerCardBanner: { flexDirection: "row", alignItems: "center", paddingHorizontal: 14, paddingVertical: 10, gap: 8 },
  verifiedPill: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  verifiedText: { fontSize: 11, fontFamily: "Inter_500Medium" },
  seasonText: { flex: 1, fontSize: 10, fontFamily: "Inter_400Regular" },
  clearBtn: { width: 26, height: 26, borderRadius: 7, alignItems: "center", justifyContent: "center" },
  playerCardBody: { alignItems: "center", paddingHorizontal: 20, paddingTop: 20, paddingBottom: 20, gap: 8 },
  avatarCircle: { width: 76, height: 76, borderRadius: 38, borderWidth: 2.5, alignItems: "center", justifyContent: "center" },
  avatarInitials: { fontSize: 28, fontFamily: "Inter_700Bold" },
  playerName: { fontSize: 24, fontFamily: "Inter_700Bold", textAlign: "center" },
  tagRow: { flexDirection: "row", alignItems: "center", gap: 10, flexWrap: "wrap", justifyContent: "center" },
  tagText: { fontSize: 15, fontFamily: "Inter_500Medium" },
  regionBadge: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 9, paddingVertical: 3, borderRadius: 7 },
  regionDot: { width: 7, height: 7, borderRadius: 3.5 },
  regionLabel: { fontSize: 12, fontFamily: "Inter_500Medium" },
  rankPill: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10 },
  rankText: { fontSize: 12, fontFamily: "Inter_500Medium" },
  puuidRow: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  puuidText: { fontSize: 10, fontFamily: "Inter_400Regular", letterSpacing: 0.5 },
});
const extStyles = StyleSheet.create({
  box: { borderRadius: 14, padding: 16, gap: 12 },
  sub: { fontSize: 12, fontFamily: "Inter_400Regular", lineHeight: 18 },
  btns: { flexDirection: "row", gap: 10 },
  btn: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, paddingVertical: 12, borderRadius: 11 },
  btnText: { color: "#fff", fontSize: 13, fontFamily: "Inter_600SemiBold" },
  infoBox: { flexDirection: "row", gap: 10, alignItems: "flex-start", borderRadius: 13, padding: 14 },
  infoText: { flex: 1, fontSize: 11, fontFamily: "Inter_400Regular", lineHeight: 17 },
});

export default function ProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const inputRef = useRef<TextInput>(null);

  const [riotId, setRiotId] = useState("");
  const [history, setHistory] = useState<string[]>([]);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [profileData, setProfileData] = useState<ProfileData | null>(null);
  const shakeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => { loadHistory().then(setHistory); }, []);

  const updateSuggestions = useCallback((text: string, hist: string[]) => {
    if (!text.trim()) { setSuggestions(hist.slice(0, 6)); setShowSuggestions(hist.length > 0); return; }
    const lower = text.toLowerCase();
    const filtered = hist.filter((h) => h.toLowerCase().includes(lower) && h.toLowerCase() !== lower);
    setSuggestions(filtered.slice(0, 6)); setShowSuggestions(filtered.length > 0);
  }, []);

  function handleChange(text: string) { setRiotId(text); setError(""); setProfileData(null); updateSuggestions(text, history); }
  function handleFocus() { updateSuggestions(riotId, history); }
  function handleBlur() { setTimeout(() => setShowSuggestions(false), 200); }

  function shake() {
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue: 10, duration: 55, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -10, duration: 55, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 6, duration: 55, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 0, duration: 55, useNativeDriver: true }),
    ]).start();
  }

  async function handleSearch(value?: string) {
    const trimmed = (value ?? riotId).trim();
    setError(""); setShowSuggestions(false); inputRef.current?.blur();
    if (!trimmed || !isValidRiotId(trimmed)) {
      setError("Digite no formato Nome#TAG — ex: SeuNome#BR1");
      shake(); Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error); return;
    }
    const parsed = parseRiotId(trimmed);
    if (!parsed) { setError("Formato inválido. Use Nome#TAG."); shake(); return; }

    setProfileData(null); setLoading(true);
    try {
      const data = await fetchProfile(parsed.name, parsed.tag);
      setProfileData(data);
      const id = `${data.account.gameName}#${data.account.tagLine}`;
      setRiotId(id);
      const next = await saveHistory(id, history);
      setHistory(next);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Erro ao buscar perfil.";
      setError(msg); shake(); Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally { setLoading(false); }
  }

  async function handleSelectSuggestion(item: string) {
    Haptics.selectionAsync(); setRiotId(item); setShowSuggestions(false); await handleSearch(item);
  }
  async function handleRemoveSuggestion(item: string) {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const next = await removeHistory(item, history); setHistory(next); updateSuggestions(riotId, next);
  }

  async function openUrl(url: string) {
    try { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); await WebBrowser.openBrowserAsync(url, { toolbarColor: "#0F1923", controlsColor: "#FF4655" }); } catch { }
  }
  function openTracker() {
    if (!profileData) return;
    const { gameName, tagLine } = profileData.account;
    openUrl(`https://tracker.gg/valorant/profile/riot/${encodeURIComponent(gameName)}%23${encodeURIComponent(tagLine)}/overview`);
  }
  function openBlitz() {
    if (!profileData) return;
    const { gameName, tagLine } = profileData.account;
    openUrl(`https://blitz.gg/valorant/profile/${encodeURIComponent(gameName)}-${encodeURIComponent(tagLine)}`);
  }
  function handleClear() { setProfileData(null); setError(""); setRiotId(""); setTimeout(() => inputRef.current?.focus(), 60); }

  const topPad = Platform.OS === "web" ? Math.max(insets.top, 67) : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  return (
    <KeyboardAvoidingView style={[s.root, { backgroundColor: colors.background }]} behavior={Platform.OS === "ios" ? "padding" : "height"}>
      <View style={[s.header, { paddingTop: topPad + 8, backgroundColor: colors.background }]}>
        <Pressable style={[s.backBtn, { backgroundColor: colors.card }]} onPress={() => router.back()}>
          <Feather name="arrow-left" size={20} color={colors.foreground} />
        </Pressable>
        <Text style={[s.headerTitle, { color: colors.foreground }]}>Tracker</Text>
        <View style={{ width: 38 }} />
      </View>

      <ScrollView
        contentContainerStyle={[s.scroll, { paddingBottom: bottomPad + 32 }]}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {!profileData && (
          <View style={[s.heroBanner, { backgroundColor: colors.card }]}>
            <View style={[s.heroDecor1, { backgroundColor: colors.primary + "14" }]} />
            <View style={[s.heroDecor2, { backgroundColor: colors.primary + "08" }]} />
            <View style={[s.heroIconRing, { borderColor: colors.primary + "55", backgroundColor: colors.primary + "18" }]}>
              <Feather name="activity" size={28} color={colors.primary} />
            </View>
            <Text style={[s.heroTitle, { color: colors.foreground }]}>Tracker Nativo</Text>
            <Text style={[s.heroSub, { color: colors.textSecondary }]}>
              Dados reais via Riot API · K/D · ACS · Partidas · Agentes
            </Text>
          </View>
        )}

        <View style={s.inputSection}>
          {!profileData && <Text style={[s.inputLabel, { color: colors.textSecondary }]}>Riot ID do jogador</Text>}
          <Animated.View style={{ transform: [{ translateX: shakeAnim }] }}>
            <View style={[s.inputRow, {
              backgroundColor: colors.card,
              borderColor: error ? colors.primary : profileData ? "#56B84799" : riotId ? colors.primary + "55" : colors.border,
            }]}>
              <Feather name="search" size={17} color={profileData ? "#56B847" : colors.textSecondary} style={{ marginRight: 10 }} />
              <TextInput
                ref={inputRef}
                style={[s.input, { color: colors.foreground }]}
                placeholder="Ex: SeuNome#BR1"
                placeholderTextColor={colors.textTertiary}
                value={riotId}
                onChangeText={handleChange}
                onFocus={handleFocus}
                onBlur={handleBlur}
                autoCapitalize="none"
                autoCorrect={false}
                returnKeyType="search"
                onSubmitEditing={() => handleSearch()}
                editable={!loading}
              />
              {loading && <ActivityIndicator size="small" color={colors.primary} />}
              {!loading && riotId.length > 0 && !profileData && (
                <Pressable onPress={() => { setRiotId(""); setError(""); setSuggestions(history.slice(0, 6)); setShowSuggestions(true); }} style={{ padding: 4 }}>
                  <Feather name="x" size={16} color={colors.textSecondary} />
                </Pressable>
              )}
              {!loading && profileData && (
                <Pressable onPress={handleClear} style={{ padding: 4 }}>
                  <Feather name="refresh-cw" size={15} color={colors.textSecondary} />
                </Pressable>
              )}
            </View>
            {error ? (
              <View style={s.errorRow}>
                <Feather name="alert-circle" size={13} color={colors.primary} />
                <Text style={[s.errorText, { color: colors.primary }]}>{error}</Text>
              </View>
            ) : !profileData ? (
              <Text style={[s.hintText, { color: colors.textTertiary }]}>Formato: NomeJogador#TAG — ex: Faker#KR1</Text>
            ) : null}
          </Animated.View>

          {showSuggestions && suggestions.length > 0 && !loading && (
            <View style={[s.suggestBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
              {suggestions.map((item) => (
                <View key={item} style={[s.suggestItem, { borderBottomColor: colors.border }]}>
                  <Pressable style={s.suggestLeft} onPress={() => handleSelectSuggestion(item)}>
                    <Feather name="clock" size={13} color={colors.textSecondary} />
                    <Text style={[s.suggestText, { color: colors.foreground }]}>{item}</Text>
                  </Pressable>
                  <Pressable onPress={() => handleRemoveSuggestion(item)} style={s.suggestRemove}>
                    <Feather name="x" size={12} color={colors.textTertiary} />
                  </Pressable>
                </View>
              ))}
            </View>
          )}

          {!profileData && !loading && (
            <Pressable style={[s.searchBtn, { backgroundColor: colors.primary }]} onPress={() => handleSearch()}>
              <Feather name="search" size={18} color="#fff" />
              <Text style={s.searchBtnText}>Buscar Jogador</Text>
            </Pressable>
          )}

          {loading && (
            <View style={[s.loadingBox, { backgroundColor: colors.card }]}>
              <ActivityIndicator size="large" color={colors.primary} />
              <Text style={[s.loadingText, { color: colors.textSecondary }]}>Consultando Riot API...</Text>
              <Text style={[s.loadingSubText, { color: colors.textTertiary }]}>Buscando perfil e histórico de partidas</Text>
            </View>
          )}
        </View>

        {profileData && !loading && (
          <TrackerView
            data={profileData}
            onClear={handleClear}
            onOpenTracker={openTracker}
            onOpenBlitz={openBlitz}
            colors={colors}
          />
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingBottom: 12 },
  backBtn: { width: 38, height: 38, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  headerTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  scroll: { paddingHorizontal: 16, paddingTop: 4, gap: 16 },
  heroBanner: { borderRadius: 16, padding: 24, alignItems: "center", overflow: "hidden", position: "relative", gap: 6 },
  heroDecor1: { position: "absolute", top: -30, right: -30, width: 120, height: 120, borderRadius: 60 },
  heroDecor2: { position: "absolute", bottom: -20, left: -20, width: 80, height: 80, borderRadius: 40 },
  heroIconRing: { width: 64, height: 64, borderRadius: 32, borderWidth: 2, alignItems: "center", justifyContent: "center", marginBottom: 4 },
  heroTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  heroSub: { fontSize: 12, fontFamily: "Inter_400Regular", textAlign: "center", lineHeight: 17 },
  inputSection: { gap: 0 },
  inputLabel: { fontSize: 13, fontFamily: "Inter_500Medium", letterSpacing: 0.4, marginBottom: 8 },
  inputRow: { flexDirection: "row", alignItems: "center", borderRadius: 13, borderWidth: 1.5, paddingHorizontal: 14, height: 54 },
  input: { flex: 1, fontSize: 15, fontFamily: "Inter_500Medium" },
  errorRow: { flexDirection: "row", alignItems: "center", gap: 5, marginTop: 7 },
  errorText: { fontSize: 13, fontFamily: "Inter_400Regular", flex: 1 },
  hintText: { fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 6 },
  suggestBox: { borderRadius: 12, borderWidth: 1, marginTop: 6, overflow: "hidden" },
  suggestItem: { flexDirection: "row", alignItems: "center", borderBottomWidth: StyleSheet.hairlineWidth },
  suggestLeft: { flex: 1, flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 14, paddingVertical: 13 },
  suggestText: { fontSize: 14, fontFamily: "Inter_400Regular" },
  suggestRemove: { paddingHorizontal: 14, paddingVertical: 13 },
  searchBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, height: 52, borderRadius: 13, marginTop: 14 },
  searchBtnText: { color: "#fff", fontSize: 15, fontFamily: "Inter_700Bold" },
  loadingBox: { borderRadius: 16, padding: 32, alignItems: "center", gap: 12, marginTop: 14 },
  loadingText: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  loadingSubText: { fontSize: 12, fontFamily: "Inter_400Regular" },
});
