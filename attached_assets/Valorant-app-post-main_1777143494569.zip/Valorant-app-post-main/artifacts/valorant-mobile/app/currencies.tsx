import { Feather } from "@expo/vector-icons";
import { useQuery } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import React from "react";
import {
  FlatList,
  Image,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { ErrorView } from "@/components/ErrorView";
import { LoadingScreen } from "@/components/LoadingScreen";
import { useColors } from "@/hooks/useColors";

interface Currency {
  uuid: string;
  displayName: string;
  displayNameSingular?: string;
  displayIcon?: string;
  largeIcon?: string;
}

async function fetchCurrencies(): Promise<Currency[]> {
  const res = await fetch("https://valorant-api.com/v1/currencies?language=pt-BR");
  const data = await res.json();
  return data.data;
}

export default function CurrenciesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ["currencies"],
    queryFn: fetchCurrencies,
  });

  const topPad = Platform.OS === "web" ? Math.max(insets.top, 67) : insets.top;

  if (isLoading) return <LoadingScreen message="Carregando moedas..." />;
  if (isError) return <ErrorView message="Não foi possível carregar as moedas" onRetry={refetch} />;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View style={[styles.headerBar, { paddingTop: topPad + 8, backgroundColor: colors.background }]}>
        <Pressable style={[styles.backBtn, { backgroundColor: colors.card }]} onPress={() => router.back()}>
          <Feather name="arrow-left" size={20} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Moedas</Text>
        <View style={{ width: 38 }} />
      </View>

      <FlatList
        data={data}
        keyExtractor={(item) => item.uuid}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: (Platform.OS === "web" ? 34 : insets.bottom) + 20, gap: 12 }}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <View style={[styles.currencyCard, { backgroundColor: colors.card }]}>
            <View style={[styles.iconBox, { backgroundColor: colors.surfaceElevated }]}>
              {item.largeIcon || item.displayIcon ? (
                <Image
                  source={{ uri: item.largeIcon || item.displayIcon }}
                  style={styles.currencyImg}
                  resizeMode="contain"
                />
              ) : (
                <Feather name="dollar-sign" size={28} color={colors.gold} />
              )}
            </View>
            <View style={styles.currencyInfo}>
              <Text style={[styles.currencyName, { color: colors.foreground }]}>{item.displayName}</Text>
              {item.displayNameSingular && item.displayNameSingular !== item.displayName ? (
                <Text style={[styles.singular, { color: colors.textSecondary }]}>
                  Singular: {item.displayNameSingular}
                </Text>
              ) : null}
            </View>
            <Feather name="dollar-sign" size={20} color={colors.gold} />
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  headerBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 12,
  },
  backBtn: { width: 38, height: 38, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  headerTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  currencyCard: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 14,
    padding: 14,
    gap: 14,
  },
  iconBox: { width: 60, height: 60, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  currencyImg: { width: 50, height: 50 },
  currencyInfo: { flex: 1 },
  currencyName: { fontSize: 17, fontFamily: "Inter_700Bold" },
  singular: { fontSize: 13, fontFamily: "Inter_400Regular", marginTop: 3 },
});
