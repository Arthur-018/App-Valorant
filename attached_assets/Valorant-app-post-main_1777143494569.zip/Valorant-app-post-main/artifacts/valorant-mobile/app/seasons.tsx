import { Feather } from "@expo/vector-icons";
import { useQuery } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import React from "react";
import {
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { ErrorView } from "@/components/ErrorView";
import { LoadingScreen } from "@/components/LoadingScreen";
import { useColors } from "@/hooks/useColors";

interface Season {
  uuid: string;
  displayName: string;
  type?: string;
  startTime?: string;
  endTime?: string;
}

async function fetchSeasons(): Promise<Season[]> {
  const res = await fetch("https://valorant-api.com/v1/seasons?language=pt-BR");
  const data = await res.json();
  return data.data.filter((s: Season) => s.displayName?.trim());
}

function formatDate(iso?: string): string {
  if (!iso) return "";
  const d = new Date(iso);
  return d.toLocaleDateString("pt-BR");
}

function seasonType(type?: string): string {
  if (!type) return "";
  if (type.includes("Episode")) return "Episódio";
  if (type.includes("Act")) return "Ato";
  return type;
}

export default function SeasonsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ["seasons"],
    queryFn: fetchSeasons,
  });

  const topPad = Platform.OS === "web" ? Math.max(insets.top, 67) : insets.top;

  if (isLoading) return <LoadingScreen message="Carregando temporadas..." />;
  if (isError) return <ErrorView message="Não foi possível carregar as temporadas" onRetry={refetch} />;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View style={[styles.headerBar, { paddingTop: topPad + 8, backgroundColor: colors.background }]}>
        <Pressable style={[styles.backBtn, { backgroundColor: colors.card }]} onPress={() => router.back()}>
          <Feather name="arrow-left" size={20} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Temporadas</Text>
        <View style={{ width: 38 }} />
      </View>

      <FlatList
        data={data}
        keyExtractor={(item) => item.uuid}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: (Platform.OS === "web" ? 34 : insets.bottom) + 20, gap: 10 }}
        showsVerticalScrollIndicator={false}
        renderItem={({ item, index }) => {
          const isEpisode = item.type?.includes("Episode");
          const color = isEpisode ? colors.primary : colors.teal;
          return (
            <View style={[styles.seasonCard, { backgroundColor: colors.card }]}>
              <View style={[styles.colorDot, { backgroundColor: color }]} />
              <View style={styles.seasonInfo}>
                <View style={styles.seasonTop}>
                  <Text style={[styles.seasonName, { color: colors.foreground }]}>{item.displayName}</Text>
                  {item.type ? (
                    <View style={[styles.typeBadge, { backgroundColor: color + "22" }]}>
                      <Text style={[styles.typeText, { color }]}>{seasonType(item.type)}</Text>
                    </View>
                  ) : null}
                </View>
                {item.startTime || item.endTime ? (
                  <Text style={[styles.dateText, { color: colors.textSecondary }]}>
                    {formatDate(item.startTime)} — {formatDate(item.endTime)}
                  </Text>
                ) : null}
              </View>
              <Feather name="calendar" size={18} color={colors.textTertiary} />
            </View>
          );
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  headerBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 12,
  },
  backBtn: { width: 38, height: 38, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  headerTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  seasonCard: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 14,
    padding: 14,
    gap: 12,
  },
  colorDot: { width: 8, height: 8, borderRadius: 4, marginTop: 2 },
  seasonInfo: { flex: 1, gap: 4 },
  seasonTop: { flexDirection: "row", alignItems: "center", gap: 8 },
  seasonName: { fontSize: 15, fontFamily: "Inter_600SemiBold", flex: 1 },
  typeBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  typeText: { fontSize: 11, fontFamily: "Inter_500Medium" },
  dateText: { fontSize: 12, fontFamily: "Inter_400Regular" },
});
