import { Feather } from "@expo/vector-icons";
import { useQuery } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import React, { useState } from "react";
import {
  FlatList,
  Image,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { ErrorView } from "@/components/ErrorView";
import { LoadingScreen } from "@/components/LoadingScreen";
import { useColors } from "@/hooks/useColors";

interface Buddy {
  uuid: string;
  displayName: string;
  displayIcon?: string;
}

async function fetchBuddies(): Promise<Buddy[]> {
  const res = await fetch("https://valorant-api.com/v1/buddies?language=pt-BR");
  const data = await res.json();
  return data.data;
}

export default function BuddiesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [search, setSearch] = useState("");

  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ["buddies"],
    queryFn: fetchBuddies,
  });

  const topPad = Platform.OS === "web" ? Math.max(insets.top, 67) : insets.top;

  const filtered = data?.filter((b) =>
    b.displayName.toLowerCase().includes(search.toLowerCase())
  );

  if (isLoading) return <LoadingScreen message="Carregando buddies..." />;
  if (isError) return <ErrorView message="Não foi possível carregar os buddies" onRetry={refetch} />;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View style={[styles.headerBar, { paddingTop: topPad + 8, backgroundColor: colors.background }]}>
        <Pressable style={[styles.backBtn, { backgroundColor: colors.card }]} onPress={() => router.back()}>
          <Feather name="arrow-left" size={20} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Buddies</Text>
        <View style={{ width: 38 }} />
      </View>

      <View style={{ marginHorizontal: 16, marginBottom: 12 }}>
        <View style={[styles.searchBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="search" size={16} color={colors.textSecondary} />
          <TextInput
            style={[styles.searchInput, { color: colors.foreground }]}
            placeholder="Buscar buddy..."
            placeholderTextColor={colors.textTertiary}
            value={search}
            onChangeText={setSearch}
          />
        </View>
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.uuid}
        numColumns={3}
        columnWrapperStyle={{ gap: 10 }}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: (Platform.OS === "web" ? 34 : insets.bottom) + 20 }}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <View style={[styles.buddyCard, { backgroundColor: colors.card }]}>
            <View style={[styles.buddyImgBox, { backgroundColor: colors.surfaceElevated }]}>
              {item.displayIcon ? (
                <Image source={{ uri: item.displayIcon }} style={styles.buddyImg} resizeMode="contain" />
              ) : (
                <Feather name="star" size={24} color={colors.textTertiary} />
              )}
            </View>
            <Text style={[styles.buddyName, { color: colors.foreground }]} numberOfLines={2}>
              {item.displayName}
            </Text>
          </View>
        )}
        ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  headerBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 12,
  },
  backBtn: { width: 38, height: 38, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  headerTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  searchBox: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 12,
    height: 44,
    gap: 8,
  },
  searchInput: { flex: 1, fontSize: 14, fontFamily: "Inter_400Regular" },
  buddyCard: { flex: 1, borderRadius: 12, padding: 10, alignItems: "center", gap: 8 },
  buddyImgBox: { width: 70, height: 70, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  buddyImg: { width: 60, height: 60 },
  buddyName: { fontSize: 11, fontFamily: "Inter_500Medium", textAlign: "center" },
});
