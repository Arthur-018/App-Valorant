import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import React, { useCallback } from "react";
import {
  Dimensions,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { CategoryCard } from "@/components/CategoryCard";
import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";

const { width } = Dimensions.get("window");

const CATEGORIES = [
  { id: "profile", title: "Tracker", subtitle: "K/D · ACS · Partidas", icon: "activity", color: "#FF4655", path: "/profile" },
  { id: "agents", title: "Agentes", subtitle: "Escolha seu lutador", icon: "shield", color: "#F5A623", path: "/agents" },
  { id: "weapons", title: "Armas", subtitle: "Arsenal completo", icon: "crosshair", color: "#00C4B4", path: "/weapons" },
  { id: "maps", title: "Mapas", subtitle: "Conheça os cenários", icon: "map", color: "#7B5BD2", path: "/maps" },
  { id: "player-cards", title: "Player Cards", subtitle: "Personalize seu perfil", icon: "credit-card", color: "#56B847", path: "/playercards" },
  { id: "buddies", title: "Buddies", subtitle: "Chaveiros de arma", icon: "star", color: "#F5A623", path: "/buddies" },
  { id: "currencies", title: "Moedas", subtitle: "Moedas do jogo", icon: "dollar-sign", color: "#FF4655", path: "/currencies" },
  { id: "gamemodes", title: "Modos", subtitle: "Formas de jogar", icon: "play-circle", color: "#00C4B4", path: "/gamemodes" },
  { id: "seasons", title: "Temporadas", subtitle: "Histórico de atos", icon: "calendar", color: "#7B5BD2", path: "/seasons" },
  { id: "titles", title: "Títulos", subtitle: "Conquistas únicas", icon: "award", color: "#56B847", path: "/titles" },
  { id: "sprays", title: "Sprays", subtitle: "Expressões no mapa", icon: "zap", color: "#FF4655", path: "/sprays" },
];

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user, logout } = useAuth();

  const topPad = Platform.OS === "web" ? Math.max(insets.top, 67) : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const handleLogout = useCallback(async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    await logout();
    router.replace("/login");
  }, [logout, router]);

  const handleCategory = useCallback((path: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push(path as any);
  }, [router]);

  const leftCategories = CATEGORIES.filter((_, i) => i % 2 === 0);
  const rightCategories = CATEGORIES.filter((_, i) => i % 2 !== 0);

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[styles.scrollContent, { paddingTop: topPad + 16, paddingBottom: bottomPad + 20 }]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <View>
            <Text style={[styles.greeting, { color: colors.textSecondary }]}>Bem-vindo,</Text>
            <Text style={[styles.username, { color: colors.foreground }]}>{user?.username ?? "Agente"}</Text>
          </View>
          <Pressable
            style={[styles.logoutBtn, { backgroundColor: colors.card }]}
            onPress={handleLogout}
          >
            <Feather name="log-out" size={18} color={colors.textSecondary} />
          </Pressable>
        </View>

        <View style={[styles.banner, { backgroundColor: colors.primary }]}>
          <View style={styles.bannerContent}>
            <Text style={styles.bannerTitle}>VALORANT</Text>
            <Text style={styles.bannerSub}>Base de dados completa</Text>
          </View>
          <View style={styles.bannerDecor}>
            <View style={[styles.decCircle1]} />
            <View style={[styles.decCircle2]} />
          </View>
          <Feather name="shield" size={48} color="rgba(255,255,255,0.15)" style={styles.bannerIcon} />
        </View>

        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Categorias</Text>

        <View style={styles.grid}>
          <View style={styles.col}>
            {leftCategories.map((cat) => (
              <CategoryCard
                key={cat.id}
                title={cat.title}
                subtitle={cat.subtitle}
                icon={cat.icon}
                color={cat.color}
                onPress={() => handleCategory(cat.path)}
              />
            ))}
          </View>
          <View style={styles.col}>
            {rightCategories.map((cat) => (
              <CategoryCard
                key={cat.id}
                title={cat.title}
                subtitle={cat.subtitle}
                icon={cat.icon}
                color={cat.color}
                onPress={() => handleCategory(cat.path)}
              />
            ))}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  scrollContent: { paddingHorizontal: 16 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 20,
  },
  greeting: { fontSize: 13, fontFamily: "Inter_400Regular" },
  username: { fontSize: 22, fontFamily: "Inter_700Bold" },
  logoutBtn: {
    width: 40,
    height: 40,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  banner: {
    borderRadius: 16,
    padding: 24,
    marginBottom: 28,
    overflow: "hidden",
    position: "relative",
  },
  bannerContent: { zIndex: 2 },
  bannerTitle: { fontSize: 26, fontFamily: "Inter_700Bold", color: "#fff", letterSpacing: 4 },
  bannerSub: { fontSize: 13, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.7)", marginTop: 4 },
  bannerDecor: { position: "absolute", top: -20, right: -20 },
  decCircle1: { width: 100, height: 100, borderRadius: 50, backgroundColor: "rgba(255,255,255,0.1)" },
  decCircle2: { width: 70, height: 70, borderRadius: 35, backgroundColor: "rgba(255,255,255,0.05)", marginTop: -40, marginLeft: 20 },
  bannerIcon: { position: "absolute", bottom: -4, right: 24 },
  sectionTitle: { fontSize: 18, fontFamily: "Inter_700Bold", marginBottom: 16 },
  grid: { flexDirection: "row", gap: 12 },
  col: { flex: 1 },
});
