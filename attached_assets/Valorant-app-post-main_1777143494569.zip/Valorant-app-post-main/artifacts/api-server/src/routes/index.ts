import { Router, type IRouter } from "express";
import healthRouter from "./health";
import riotRouter from "./riot";

const router: IRouter = Router();

router.use(healthRouter);
router.use(riotRouter);

export default router;
