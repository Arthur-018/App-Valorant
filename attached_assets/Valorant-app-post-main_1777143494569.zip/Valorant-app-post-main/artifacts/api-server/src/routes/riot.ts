import { Router, type IRouter, type Request, type Response } from "express";
import { logger } from "../lib/logger.js";

const router: IRouter = Router();

const RIOT_ACCOUNT_HOST = "https://americas.api.riotgames.com";

const SHARD_MAP: Record<string, string> = {
  BR1: "br", NA1: "na", NA: "na", LA1: "latam", LA2: "latam",
  EUW: "eu", EUW1: "eu", EUNE: "eu", TR1: "eu", RU: "eu",
  KR: "kr", JP1: "ap", JP: "ap", AP: "ap", OC1: "ap", ME1: "eu",
};

function getShard(tag: string): string {
  return SHARD_MAP[tag.toUpperCase()] ?? "na";
}

function getRiotApiKey(): string | null {
  return process.env["RIOT_API_KEY"] ?? null;
}

function getMapName(mapId: string): string {
  if (!mapId) return "Mapa Desconhecido";
  const parts = mapId.split("/");
  return parts[parts.length - 1] || mapId;
}

function getGameMode(queueId: string): string {
  const modes: Record<string, string> = {
    competitive: "Competitivo",
    unranked: "Sem Ranque",
    spikerush: "Spike Rush",
    deathmatch: "Deathmatch",
    ggteam: "Escalada",
    onefa: "Replication",
    hurm: "Team Deathmatch",
    premier: "Premier",
    swiftplay: "Swift Play",
    newmap: "Novo Mapa",
  };
  return modes[queueId] ?? queueId ?? "Partida";
}

const RANK_NAMES = [
  "Não Ranqueado", "Não Ranqueado", "Não Ranqueado",
  "Ferro 1", "Ferro 2", "Ferro 3",
  "Bronze 1", "Bronze 2", "Bronze 3",
  "Prata 1", "Prata 2", "Prata 3",
  "Ouro 1", "Ouro 2", "Ouro 3",
  "Platina 1", "Platina 2", "Platina 3",
  "Diamante 1", "Diamante 2", "Diamante 3",
  "Ascendente 1", "Ascendente 2", "Ascendente 3",
  "Imortal 1", "Imortal 2", "Imortal 3",
  "Radiante",
];

function getRankName(tier: number): string {
  return RANK_NAMES[tier] ?? "Não Ranqueado";
}

interface AgentInfo { id: string; name: string; iconUrl: string; }
let agentCache: AgentInfo[] = [];
let agentCacheTime = 0;
const AGENT_TTL = 3_600_000;

async function getAgents(): Promise<AgentInfo[]> {
  if (agentCache.length && Date.now() - agentCacheTime < AGENT_TTL) return agentCache;
  try {
    const res = await fetch("https://valorant-api.com/v1/agents?isPlayableCharacter=true&language=pt-BR");
    const data = await res.json() as { data: Array<{ uuid: string; displayName: string; displayIconSmall: string }> };
    agentCache = data.data.map((a) => ({ id: a.uuid.toLowerCase(), name: a.displayName, iconUrl: a.displayIconSmall }));
    agentCacheTime = Date.now();
  } catch (err) {
    logger.warn({ err }, "Failed to fetch agents from valorant-api.com");
  }
  return agentCache;
}

function findAgent(agents: AgentInfo[], characterId: string): AgentInfo {
  return agents.find((a) => a.id === characterId.toLowerCase()) ?? { id: characterId, name: "Agente", iconUrl: "" };
}

async function riotGet(url: string, apiKey: string): Promise<{ status: number; body: unknown }> {
  try {
    const res = await fetch(url, {
      headers: {
        "X-Riot-Token": apiKey,
        "Accept-Language": "pt-BR,pt;q=0.9",
      },
    });
    let body: unknown;
    try { body = await res.json(); } catch { body = {}; }
    return { status: res.status, body };
  } catch (err) {
    logger.error({ err, url }, "Riot API network error");
    return { status: 503, body: {} };
  }
}

router.get("/riot/account", async (req: Request, res: Response) => {
  const { name, tag } = req.query as { name?: string; tag?: string };
  if (!name || !tag) { res.status(400).json({ error: "Parâmetros 'name' e 'tag' são obrigatórios." }); return; }

  const apiKey = getRiotApiKey();
  if (!apiKey) { res.status(503).json({ error: "RIOT_API_KEY não configurada.", code: "KEY_MISSING" }); return; }

  const { status, body } = await riotGet(
    `${RIOT_ACCOUNT_HOST}/riot/account/v1/accounts/by-riot-id/${encodeURIComponent(name)}/${encodeURIComponent(tag)}`,
    apiKey,
  );
  const d = body as Record<string, unknown>;

  if (status === 404) { res.status(404).json({ error: "Conta não encontrada. Verifique o Riot ID e tente novamente." }); return; }
  if (status === 401 || status === 403) { res.status(401).json({ error: "Chave da Riot API inválida ou sem permissão.", code: "KEY_INVALID" }); return; }
  if (status === 429) { res.status(429).json({ error: "Limite de requisições atingido. Aguarde um momento." }); return; }
  if (status !== 200) { res.status(502).json({ error: "Serviço da Riot temporariamente indisponível." }); return; }

  res.json({ puuid: d.puuid, gameName: d.gameName, tagLine: d.tagLine, shard: getShard(String(tag)) });
});

router.get("/riot/profile", async (req: Request, res: Response) => {
  const { name, tag } = req.query as { name?: string; tag?: string };
  if (!name || !tag) { res.status(400).json({ error: "Parâmetros 'name' e 'tag' são obrigatórios." }); return; }

  const apiKey = getRiotApiKey();
  if (!apiKey) { res.status(503).json({ error: "RIOT_API_KEY não configurada.", code: "KEY_MISSING" }); return; }

  const shard = getShard(tag);

  const accountResult = await riotGet(
    `${RIOT_ACCOUNT_HOST}/riot/account/v1/accounts/by-riot-id/${encodeURIComponent(name)}/${encodeURIComponent(tag)}`,
    apiKey,
  );

  if (accountResult.status === 404) { res.status(404).json({ error: "Conta não encontrada. Verifique o Riot ID." }); return; }
  if (accountResult.status === 401 || accountResult.status === 403) { res.status(401).json({ error: "Chave da Riot API inválida ou sem permissão.", code: "KEY_INVALID" }); return; }
  if (accountResult.status === 429) { res.status(429).json({ error: "Limite de requisições atingido. Aguarde um momento." }); return; }
  if (accountResult.status !== 200) { res.status(502).json({ error: "Serviço da Riot temporariamente indisponível." }); return; }

  const acc = accountResult.body as { puuid: string; gameName: string; tagLine: string };

  const [contentResult, matchListResult, agents] = await Promise.all([
    riotGet(`https://${shard}.api.riotgames.com/val/content/v1/contents?locale=pt-BR`, apiKey),
    riotGet(`https://${shard}.api.riotgames.com/val/match/v1/matchlists/by-puuid/${encodeURIComponent(acc.puuid)}`, apiKey),
    getAgents(),
  ]);

  const contentData = contentResult.status === 200
    ? (contentResult.body as { acts?: Array<{ id: string; name: string; isActive: boolean; type: string }>; version?: string })
    : null;

  const currentAct = contentData?.acts?.find((a) => a.isActive && a.type === "act");
  const currentEpisode = contentData?.acts?.find((a) => a.isActive && a.type === "episode");
  const gameVersion = contentData?.version ?? null;

  const matchesAvailable = matchListResult.status === 200;
  const matchListData = matchesAvailable
    ? (matchListResult.body as { history?: Array<{ matchId: string; gameStartTimeMillis: number; queueId: string }> })
    : null;
  const matchIds = matchListData?.history?.slice(0, 10) ?? [];

  let recentMatches: unknown[] = [];
  let overview: unknown = null;
  let topAgents: unknown[] = [];
  let matchDataAvailable = false;

  if (matchesAvailable && matchIds.length > 0) {
    matchDataAvailable = true;

    const matchResults = await Promise.allSettled(
      matchIds.slice(0, 8).map((m) =>
        riotGet(
          `https://${shard}.api.riotgames.com/val/match/v1/matches/${encodeURIComponent(m.matchId)}`,
          apiKey,
        ),
      ),
    );

    type MatchPlayer = {
      puuid: string; teamId: string; characterId: string;
      stats: { score: number; roundsPlayed: number; kills: number; deaths: number; assists: number };
      competitiveTier: number; gameName: string; tagLine: string;
    };
    type MatchTeam = { teamId: string; won: boolean; roundsPlayed: number; roundsWon: number };
    type MatchData = {
      matchInfo: { matchId: string; mapId: string; gameStartMillis: number; isRanked: boolean; gameMode: string };
      players: MatchPlayer[];
      teams: MatchTeam[];
    };

    const parsed: Array<{ raw: MatchData; queueId: string; startedAt: number }> = [];

    for (let i = 0; i < matchResults.length; i++) {
      const r = matchResults[i];
      if (r.status === "rejected") continue;
      const { status, body } = r.value;
      if (status !== 200) continue;
      const md = body as MatchData;
      if (!md.players || !md.teams) continue;
      const meta = matchIds[i];
      if (meta) parsed.push({ raw: md, queueId: meta.queueId, startedAt: meta.gameStartTimeMillis });
    }

    const agentStats: Record<string, { name: string; iconUrl: string; games: number; wins: number; kills: number; deaths: number; assists: number; score: number; rounds: number }> = {};
    let totalGames = 0, totalWins = 0, totalKills = 0, totalDeaths = 0, totalAssists = 0, totalScore = 0, totalRounds = 0;
    let lastKnownTier = 0;

    recentMatches = parsed.map(({ raw, queueId, startedAt }) => {
      const player = raw.players.find((p) => p.puuid === acc.puuid);
      if (!player) return null;

      const myTeam = raw.teams.find((t) => t.teamId === player.teamId);
      const enemyTeam = raw.teams.find((t) => t.teamId !== player.teamId);
      const won = myTeam?.won ?? false;

      const { kills, deaths, assists, score, roundsPlayed } = player.stats;
      const acs = roundsPlayed > 0 ? Math.round(score / roundsPlayed) : 0;
      const kd = deaths > 0 ? (kills / deaths).toFixed(2) : kills.toFixed(2);

      if (player.competitiveTier > 0) lastKnownTier = player.competitiveTier;

      totalGames++;
      if (won) totalWins++;
      totalKills += kills;
      totalDeaths += deaths;
      totalAssists += assists;
      totalScore += score;
      totalRounds += roundsPlayed;

      const charId = player.characterId?.toLowerCase();
      const agent = findAgent(agents, charId ?? "");
      if (charId) {
        if (!agentStats[charId]) agentStats[charId] = { name: agent.name, iconUrl: agent.iconUrl, games: 0, wins: 0, kills: 0, deaths: 0, assists: 0, score: 0, rounds: 0 };
        const as = agentStats[charId]!;
        as.games++;
        if (won) as.wins++;
        as.kills += kills;
        as.deaths += deaths;
        as.assists += assists;
        as.score += score;
        as.rounds += roundsPlayed;
      }

      return {
        matchId: raw.matchInfo.matchId,
        queue: queueId,
        queueLabel: getGameMode(queueId),
        startedAt,
        result: won ? "win" : "loss",
        agent: { id: player.characterId, name: agent.name, iconUrl: agent.iconUrl },
        map: getMapName(raw.matchInfo.mapId),
        roundsWon: myTeam?.roundsWon ?? 0,
        roundsLost: enemyTeam?.roundsWon ?? 0,
        kills, deaths, assists, acs,
        kd,
        isRanked: raw.matchInfo.isRanked,
        competitiveTier: player.competitiveTier,
        rankName: getRankName(player.competitiveTier),
        roundsPlayed,
      };
    }).filter(Boolean);

    if (totalGames > 0) {
      const kd = totalDeaths > 0 ? (totalKills / totalDeaths).toFixed(2) : totalKills.toFixed(1);
      const kda = totalDeaths > 0 ? ((totalKills + totalAssists) / totalDeaths).toFixed(2) : (totalKills + totalAssists).toFixed(1);
      overview = {
        totalGames,
        wins: totalWins,
        losses: totalGames - totalWins,
        winRate: Math.round((totalWins / totalGames) * 100),
        kdRatio: kd,
        kdaRatio: kda,
        avgACS: totalRounds > 0 ? Math.round(totalScore / totalRounds) : 0,
        avgKills: (totalKills / totalGames).toFixed(1),
        avgDeaths: (totalDeaths / totalGames).toFixed(1),
        avgAssists: (totalAssists / totalGames).toFixed(1),
        lastKnownTier,
        lastKnownRank: getRankName(lastKnownTier),
        totalKills, totalDeaths, totalAssists,
      };
    }

    topAgents = Object.entries(agentStats)
      .map(([id, s]) => ({
        id,
        name: s.name,
        iconUrl: s.iconUrl,
        games: s.games,
        wins: s.wins,
        winRate: Math.round((s.wins / s.games) * 100),
        kills: s.kills,
        deaths: s.deaths,
        assists: s.assists,
        kd: s.deaths > 0 ? (s.kills / s.deaths).toFixed(2) : s.kills.toFixed(1),
        avgACS: s.rounds > 0 ? Math.round(s.score / s.rounds) : 0,
      }))
      .sort((a, b) => b.games - a.games)
      .slice(0, 5);
  }

  res.json({
    account: {
      puuid: acc.puuid,
      gameName: acc.gameName,
      tagLine: acc.tagLine,
      shard,
    },
    season: {
      act: currentAct ? { id: currentAct.id, name: currentAct.name } : null,
      episode: currentEpisode ? { id: currentEpisode.id, name: currentEpisode.name } : null,
      gameVersion,
    },
    dataAvailability: {
      matches: matchesAvailable,
      matchDetails: matchDataAvailable,
      rank: false,
    },
    overview: overview ?? null,
    topAgents,
    recentMatches,
  });
});

router.get("/riot/match", async (req: Request, res: Response) => {
  const { matchId, shard } = req.query as { matchId?: string; shard?: string };
  if (!matchId || !shard) { res.status(400).json({ error: "Parâmetros 'matchId' e 'shard' são obrigatórios." }); return; }

  const apiKey = getRiotApiKey();
  if (!apiKey) { res.status(503).json({ error: "RIOT_API_KEY não configurada.", code: "KEY_MISSING" }); return; }

  const { status, body } = await riotGet(
    `https://${encodeURIComponent(shard)}.api.riotgames.com/val/match/v1/matches/${encodeURIComponent(matchId)}`,
    apiKey,
  );

  if (status !== 200) { res.status(status).json({ error: "Partida não encontrada ou indisponível." }); return; }
  res.json(body);
});

export default router;
