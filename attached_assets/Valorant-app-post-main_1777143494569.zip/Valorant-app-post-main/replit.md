# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.

## Artifacts

### Valorant Mobile (`artifacts/valorant-mobile`)
- **Type**: Expo (React Native) mobile app
- **Preview Path**: `/`
- **Description**: Valorant Companion App with Valorant API integration
- **Features**:
  - Login/Register screen (AsyncStorage-based auth)
  - Home screen with category cards (10 categories)
  - Agents list + detail with abilities
  - Weapons list + detail + skins gallery
  - Maps with splash images
  - Player Cards gallery
  - Buddies gallery
  - Currencies
  - Game Modes
  - Seasons/Acts timeline
  - Player Titles
  - Sprays gallery
- **API**: valorant-api.com (pt-BR language)
- **Theme**: Dark navy (#0F1923) with Valorant red (#FF4655) accents
- **Fonts**: Inter (400/500/600/700) via @expo-google-fonts/inter
- **State**: React Query for API, AsyncStorage for auth persistence
